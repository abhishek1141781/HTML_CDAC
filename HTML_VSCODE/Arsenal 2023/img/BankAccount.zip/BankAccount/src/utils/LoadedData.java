package utils;

import java.time.LocalDate;
import java.util.ArrayList;

import com.app.banking.BankAccount;
import com.app.enums.AccountType;

public class LoadedData {

	public static ArrayList<BankAccount> loadedList() {
		
		ArrayList<BankAccount> bank = new ArrayList<BankAccount>();
		bank.add(new BankAccount(1, "Omkar", AccountType.valueOf("SAVING"), 20000, LocalDate.now()));
		bank.add(new BankAccount(4, "Laxmikant", AccountType.valueOf("CURRENT"), 43000, LocalDate.now()));
		bank.add(new BankAccount(6, "Atul", AccountType.valueOf("FD"), 27000, LocalDate.now()));
		bank.add(new BankAccount(3, "Amber", AccountType.valueOf("NRE"), 44000, LocalDate.now()));
		bank.add(new BankAccount(2, "Sumit", AccountType.valueOf("FD"), 36000, LocalDate.now()));
		return bank;
		
	}

}
