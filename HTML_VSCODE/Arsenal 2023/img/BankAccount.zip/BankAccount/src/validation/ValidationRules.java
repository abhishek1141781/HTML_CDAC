package validation;

import java.util.ArrayList;

import com.app.banking.BankAccount;
import com.app.enums.AccountType;

import exception.CustomException;

public class ValidationRules {
	public static void validateAccNo(int accNo, ArrayList<BankAccount> bank) throws CustomException {
		if (bank.contains(new BankAccount(accNo))) {
			throw new CustomException("Account Already Exist");
		}
	}

	public static void validateMinimumAmount(AccountType acctype, double balance) throws CustomException {
		if (acctype.getMinimunAmount() > balance) {
			throw new CustomException("The balance is less than the Minimum balance");
		}

	}
}
